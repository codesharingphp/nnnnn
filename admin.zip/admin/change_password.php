<?php
session_start();
include("includes/config.php");
if (!isset($_SESSION['alogin'])) {
  header ('location: login.php'); 
  exit;
}?>

<?php
if(isset($_POST['submit'])){
$sql=mysqli_query($connection,"SELECT password FROM  admin where password='".md5($_POST['password'])."' && username='".$_SESSION['alogin']."'");
$num=mysqli_fetch_array($sql);
if($num>0)
{
$con=mysqli_query($connection,"update admin set password='".md5($_POST['newpassword'])."' where username='".$_SESSION['alogin']."'");
$_SESSION['msg']="Password Changed Successfully !!";
}
else
{
$_SESSION['msg']="Old Password not match !!";
}
}
?>

<!-- /////////////////////////////////////////////////////////////////////////// -->
<?php include("includes/header.php");?>

<?php include("includes/sidebar.php");?>
<!-- Main Wrapper -->
<div id="wrapper">
<div class="normalheader transition animated fadeIn">
<div class="hpanel">
<div class="panel-body">
<a class="small-header-action" href="">
<div class="clip-header">
<i class="fa fa-arrow-up"></i>
</div>
</a>
<div id="hbreadcrumb" class="pull-right m-t-lg">
<ol class="hbreadcrumb breadcrumb">
<li><a href="index.php">Dashboard</a></li>
</ol>
</div>
<h2 class="font-light m-b-xs">
Admin Change Password
</h2>
</div>
</center>
</div>
</div>
<div class="content"  >
<div class="row">
<div class="col-lg-3"></div>
<div class="col-lg-6">
<div class="hpanel">

<!-- ////////////////////////successful insert alert//////////////////////////////////////-->
<!-- ////////////////////////////////////////////////////////////////////////////////////// -->
<?php if(isset($_POST['submit'])){?>
<div class="alert alert-success">
<button type="button" class="close" data-dismiss="alert">×</button>
<?php echo htmlentities($_SESSION['msg']);?><?php echo htmlentities($_SESSION['msg']="");?>
</div>
<?php } ?>
<br/>

<div class="panel-body">
<form role="form" id="form" name="chngpwd" method="post" onSubmit="return valid();">
<div class="control-group">
<label class="control-label" for="basicinput">Current Password</label>
<div class="controls">
<input type="password" placeholder="Enter your current Password"  name="password" class="form-control" required>
</div>
</div>
<div class="control-group">
<label class="control-label" for="basicinput">New Password</label>
<div class="controls">
<input type="password" placeholder="Enter your new current Password"  name="newpassword" class="form-control"required>
</div>
</div>
<div class="control-group">
<label class="control-label" for="basicinput">Current Password</label>
<div class="controls">
<input type="password" placeholder="Enter your new Password again"  name="confirmpassword" class="form-control" required>
</div>
</div>
<div>
<button style="margin-top:20px;" name="submit" class="btn btn-sm btn-primary m-t-n-xs" type="submit"><strong>Create</strong></button>
</div>
</form>
</div>
</div>
</div>
<div class="col-lg-3"></div>

</div>
</div>



 <!-- //////////////////////////////////////////////////////////////////////////////// -->

 <?php include("includes/footer.php");?>



<!-- Vendor scripts -->
<script src="vendor/jquery/dist/jquery.min.js"></script>
<script src="vendor/jquery-ui/jquery-ui.min.js"></script>
<script src="vendor/slimScroll/jquery.slimscroll.min.js"></script>
<script src="vendor/bootstrap/dist/js/bootstrap.min.js"></script>
<script src="vendor/metisMenu/dist/metisMenu.min.js"></script>
<script src="vendor/iCheck/icheck.min.js"></script>
<script src="vendor/sparkline/index.js"></script>
<!-- DataTables -->
<script src="vendor/datatables/media/js/jquery.dataTables.min.js"></script>
<script src="vendor/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
<!-- DataTables buttons scripts -->
<script src="vendor/pdfmake/build/pdfmake.min.js"></script>
<script src="vendor/pdfmake/build/vfs_fonts.js"></script>
<script src="vendor/datatables.net-buttons/js/buttons.php5.min.js"></script>
<script src="vendor/datatables.net-buttons/js/buttons.print.min.js"></script>
<script src="vendor/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
<script src="vendor/datatables.net-buttons-bs/js/buttons.bootstrap.min.js"></script>
<!-- App scripts -->
<script src="scripts/homer.js"></script>


<script>

    $(function () {

        // Initialize Example 1
        $('#example1').dataTable( {
            "ajax": 'api/datatables.json',
            dom: "<'row'<'col-sm-4'l><'col-sm-4 text-center'B><'col-sm-4'f>>tp",
            "lengthMenu": [ [10, 25, 50, -1], [10, 25, 50, "All"] ],
            buttons: [
                {extend: 'copy',className: 'btn-sm'},
                {extend: 'csv',title: 'ExampleFile', className: 'btn-sm'},
                {extend: 'pdf', title: 'ExampleFile', className: 'btn-sm'},
                {extend: 'print',className: 'btn-sm'}
            ]
        });

        // Initialize Example 2
        $('#example2').dataTable();

    });

</script>

</body>
</html>