<?php
session_start();
include('includes/config.php');
if (!isset($_SESSION['alogin'])) {
  header ('location: login.php'); 
  exit;
}
if(isset($_POST['submit']))
{
    $category=$_POST['category'];
    $subcategory=$_POST['subcategory'];
    $productname=$_POST['productname'];
    $productprice=$_POST['productprice'];
    $productdescription=$_POST['productdescription'];
    $productimage=$_FILES["productimage"]["name"];



      $file= $_FILES['productimage']['name'];
      $temp= $_FILES['productimage']['tmp_name'];    
      move_uploaded_file($temp,"uploads/product/".$file);

      $query=mysqli_query($connection,"select id from products");
      $result=mysqli_fetch_array($query);
   
      $sql=mysqli_query($connection,"insert into products(category,subcategory,productname,productprice,productdescription,productimage) values('$category','$subcategory','$productname','$productprice','$productdescription','$productimage')");
      $_SESSION['msg']="Product Inserted Successfully !!";

   }

   if(isset($_GET['del']))
{
mysqli_query($connection,"delete from products where id = '".$_GET['id']."'");
$_SESSION['delmsg']="product deleted !!";
}
   
?>



<!-- ///////////////////////////////////////////////////////////// -->
<?php include("includes/header.php");?>
<!-- Navigation -->
<?php include("includes/sidebar.php");?>

<!-- Main Wrapper -->
<div id="wrapper">
<div class="small-header transition animated fadeIn">
<div class="hpanel">
<div class="panel-body">
<h2 class="font-light m-b-xs text-center" style="font-size: 20px">Add Products</h2>
</div>
</div>
</div>
<div class="content animate-panel">
<div>
<div class="row">
<div class="col-lg-12">
<div class="hpanel">
</div>
</div>
</div>
<div class="row">
<div class="col-lg-6">
<div class="hpanel">
<!-- ////////////////////////successful insert alert//////////////////////////////////////-->

<?php if(isset($_POST['submit'])){?>
<div class="alert alert-success">
<button type="button" class="close" data-dismiss="alert">×</button>
<strong></strong> <?php echo htmlentities($_SESSION['msg']);?><?php echo htmlentities($_SESSION['msg']="");?>
</div>
<?php } ?>
<!-- ///////////////////////////////////////////////////////////////////////////////////// -->
<!-- ////////////////////////successful delete alert//////////////////////////////////////-->
<?php if(isset($_GET['del']))
{?>
<div class="alert alert-danger">
<button type="button" class="close" data-dismiss="alert">×</button>
<strong></strong><?php echo htmlentities($_SESSION['delmsg']);?><?php echo htmlentities($_SESSION['delmsg']="");?>
</div>
<?php } ?>
<br />
<!-- //////////////////////////////////////////////////////////////////////////////////// -->
<!-- ////////////////////////////////////////////////////////////////////////////////////// -->

<div class="panel-body " >
<form role="form" id="form"  name="insertproduct" method="post" enctype="multipart/form-data">
<div class="form-group"><label>Category</label> 

<select name="category" placeholder="Category " class="form-control" onChange="getSubcat(this.value);" required></div>
<option value="">Select Category</option> 
<?php $query=mysqli_query($connection,"select * from category");
while($row=mysqli_fetch_array($query))
{?>
<option value="<?php echo $row['id'];?>"><?php echo $row['category'];?></option>
<?php } ?>
</select>

<div class="form-group"><label>Sub Category</label>
<select  name="subcategory"  id="subcategory" placeholder="Subcategory " class="form-control"  required></div>
</select>

<div class="form-group"><label>Product Name</label>
<input type="text"    name="productname"  placeholder="Enter Product Name" class="form-control"required></div>

<div class="form-group"><label>Product Price</label>
<input type="text"    name="productprice"  placeholder="Enter Product Price" class="form-control"required></div>
<div class="form-group"><label>Product Description</label> 
<textarea  name="productdescription"  placeholder="Enter Product Description" rows="6"  class="form-control"></textarea>  </div>


<div class="form-group"><label>Product Image</label>
<input type="file" name="productimage" id="productimage" value="" class="form-control"  required><div>


<button style="margin-top:15px;" name="submit" class="btn btn-sm btn-primary m-t-n-xs" type="submit"><strong>Insert</strong></button>
</div>
</form>
</div>
</div>
</div>
</div>
</div>
<!-- ////////////////////////////////////////////////////////////////////////////// -->
<!-- ////////////////////////////Table////////////////////////////////////////////////// -->
<div class="row">
<div class="col-lg-12">
<div class="hpanel">
<div class="panel-body" style="width: 200%;">
<table id="example2" class="table table-striped table-bordered table-hover ">
<thead>
<tr>
<th>Id</th>
<th>Category</th>
<th>Subcategory</th>
<th>product Name</th>
<th>product Price</th>
<th>product Description</th>
<th>Creation Date</th>
<th>Product Image</th>
<th>Action</th>
</tr>
</thead>
<tbody>
<?php $query=mysqli_query($connection,"select * from products");
$cnt=1;
while($row=mysqli_fetch_array($query)){
?>                                  
<tr>
<td><?php echo ($cnt);?></td>
<td><?php echo ($row['category']);?></td>
<td><?php echo ($row['subcategory']);?></td>
<td><?php echo ($row['productname']);?></td>
<td><?php echo ($row['productprice']);?></td>
<td><?php echo ($row['productdescription']);?></td>
<td><?php echo($row['creationDate']);?></td>
<td><img src="uploads/product/<?php echo ($row['productimage']);?>" height="30px" width="60px"></a></td>
<td>
<a class = "btn btn-danger btn-xs " href="insert_product.php?id=<?php echo $row['id']?>&del=delete"><span class="glyphicon glyphicon-trash"></a></td>
</tr>
<?php $cnt=$cnt+1; } ?>
</tbody>
</table>

</div>
</div>
</div>

</div>
</div>

<!-- ////////////////////////////////////////////////////////////////////////////////// -->
<?php include("includes/footer.php");?>
</div>



<!-- Vendor scripts -->
<script src="vendor/jquery/dist/jquery.min.js"></script>
<script src="vendor/jquery-ui/jquery-ui.min.js"></script>
<script src="vendor/slimScroll/jquery.slimscroll.min.js"></script>
<script src="vendor/bootstrap/dist/js/bootstrap.min.js"></script>
<script src="vendor/metisMenu/dist/metisMenu.min.js"></script>
<script src="vendor/iCheck/icheck.min.js"></script>
<script src="vendor/sparkline/index.js"></script>
<!-- DataTables -->
<script src="vendor/datatables/media/js/jquery.dataTables.min.js"></script>
<script src="vendor/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
<!-- DataTables buttons scripts -->
<script src="vendor/pdfmake/build/pdfmake.min.js"></script>
<script src="vendor/pdfmake/build/vfs_fonts.js"></script>
<script src="vendor/datatables.net-buttons/js/buttons.html5.min.js"></script>
<script src="vendor/datatables.net-buttons/js/buttons.print.min.js"></script>
<script src="vendor/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
<script src="vendor/datatables.net-buttons-bs/js/buttons.bootstrap.min.js"></script>
<!-- App scripts -->
<script src="scripts/homer.js"></script>


<script>

$(function () {

// Initialize Example 1
$('#example1').dataTable( {
"ajax": 'api/datatables.json',
dom: "<'row'<'col-sm-4'l><'col-sm-4 text-center'B><'col-sm-4'f>>tp",
"lengthMenu": [ [10, 25, 50, -1], [10, 25, 50, "All"] ],
buttons: [
{extend: 'copy',className: 'btn-sm'},
{extend: 'csv',title: 'ExampleFile', className: 'btn-sm'},
{extend: 'pdf', title: 'ExampleFile', className: 'btn-sm'},
{extend: 'print',className: 'btn-sm'}
]
});

// Initialize Example 2
$('#example2').dataTable();

});

</script>

</body>
</html>